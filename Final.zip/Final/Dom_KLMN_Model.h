//DOM-KLMN - Projeto Domino - Etapa 6
//20/09/2023

#define MAX 28
int numeroJogadas;
int J; //jogador da vez
int indicePeca; //indice das pecas (a-h)
bool fimJogo;
int opc; //opcao de escolha do menu
bool jogoMaquina; //se o jogo for contra a maquina
int qtdPecasDeposito;