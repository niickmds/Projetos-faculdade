//DOM-KLMN - Projeto Domino - Etapa 6
//20/09/2023

void fMenuInicio ();
void fPrintPrimeiroJogador();
void fMensagem ();
void fMesa ();
void fPrintPecas (int jogador);
void fPrintVencedor(int jogador);
char fEscolhaChar();
void fPrintResultadoMaquina(int compras, bool jogadaFoiPassada);
void fPrintRegras();