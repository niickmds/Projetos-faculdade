//DOM-KLMN - Projeto Domino - Etapa 6
//20/09/2023
//GRUPO: F.A.M.I.L.I.A. (Fundacao Amigos da Modernidade Impetuosamente Leviana de Inquietos Anafilaticos)
//Kaua Cordeiro, Luan Capella, Manoela Martedi, Nicolas Mariano

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h> //toupper
#include "Dom_KLMN_Model.cpp"
#include "Dom_KLMN_Controller.cpp"

int main ()
{
	fGerarDomino ();
	fIniciarJogo();
}